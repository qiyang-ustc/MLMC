#ifndef __MY_INIT__
#define __MY_INIT__
extern void initialize();
extern int* Obj_find(int);
extern int* find(int);
#endif // !__MY_INIT__

