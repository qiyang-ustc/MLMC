#ifndef __MY_STAT__
#define __MY_STAT__
extern void coll_data(int);
extern void norm_Nsamp(int);
extern void stat_analy();
extern void write2file();
#endif // !__MY_STAT__

