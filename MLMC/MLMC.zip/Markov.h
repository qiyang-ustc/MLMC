#ifndef __MARKOV__
#define __MARKOV__
extern void Markov();
#endif